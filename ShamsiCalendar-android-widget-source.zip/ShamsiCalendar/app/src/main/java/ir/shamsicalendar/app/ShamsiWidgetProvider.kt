package ir.shamsicalendar.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews
import java.time.LocalDate

class ShamsiWidgetProvider : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val prefs = context.getSharedPreferences(CalendarData.PREFS, Context.MODE_PRIVATE)
        when (intent.action) {
            ACTION_PREV, ACTION_NEXT -> {
                val todayJ = JalaliDate.fromGregorian(LocalDate.now())
                var y = prefs.getInt(KEY_YEAR, todayJ.year)
                var m = prefs.getInt(KEY_MONTH, todayJ.month)
                if (intent.action == ACTION_PREV) { if (m == 1) { m = 12; y-- } else m-- }
                else { if (m == 12) { m = 1; y++ } else m++ }
                prefs.edit().putInt(KEY_YEAR, y).putInt(KEY_MONTH, m).putInt(KEY_DAY, 1).apply()
                refresh(context)
            }
            ACTION_TODAY -> {
                val t = JalaliDate.fromGregorian(LocalDate.now())
                prefs.edit().putInt(KEY_YEAR, t.year).putInt(KEY_MONTH, t.month).putInt(KEY_DAY, t.day).apply()
                refresh(context)
            }
            ACTION_SELECT_DAY -> {
                val y = intent.getIntExtra(CalendarData.EXTRA_YEAR, 0)
                val m = intent.getIntExtra(CalendarData.EXTRA_MONTH, 0)
                val d = intent.getIntExtra(CalendarData.EXTRA_DAY, 0)
                if (y > 0 && m in 1..12 && d > 0) prefs.edit().putInt(KEY_YEAR,y).putInt(KEY_MONTH,m).putInt(KEY_DAY,d).apply()
                refresh(context)
            }
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    companion object {
        const val ACTION_PREV = "ir.shamsicalendar.PREV_MONTH"
        const val ACTION_NEXT = "ir.shamsicalendar.NEXT_MONTH"
        const val ACTION_TODAY = "ir.shamsicalendar.TODAY"
        const val ACTION_SELECT_DAY = "ir.shamsicalendar.SELECT_DAY"
        const val KEY_YEAR = "widget_year"
        const val KEY_MONTH = "widget_month"
        const val KEY_DAY = "widget_day"

        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ShamsiWidgetProvider::class.java))
            if (ids.isNotEmpty()) ShamsiWidgetProvider().onUpdate(context, manager, ids)
        }

        private fun digits(value: Int) = value.toString().map { if (it in '0'..'9') ('۰'.code + it.code - '0'.code).toChar() else it }.joinToString("")

        private fun broadcastPending(context: Context, action: String, requestCode: Int): PendingIntent {
            val i = Intent(context, ShamsiWidgetProvider::class.java).setAction(action)
            return PendingIntent.getBroadcast(context, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val prefs = context.getSharedPreferences(CalendarData.PREFS, Context.MODE_PRIVATE)
            val today = JalaliDate.fromGregorian(LocalDate.now())
            val y = prefs.getInt(KEY_YEAR, today.year)
            val m = prefs.getInt(KEY_MONTH, today.month)
            val selected = prefs.getInt(KEY_DAY, today.day).coerceIn(1, JalaliDate.daysInMonth(y,m))
            val start = JalaliDate.toGregorian(y,m,1)
            val offset = (start.dayOfWeek.value + 1) % 7 // Saturday-first: Sat=0, Sun=1
            val count = JalaliDate.daysInMonth(y,m)
            val monthStart = start
            val monthEnd = if (m == 12) JalaliDate.toGregorian(y + 1,1,1) else JalaliDate.toGregorian(y,m+1,1)
            val events = CalendarData.eventsForGregorianRange(context, monthStart, monthEnd)
            val eventsByDay = events.groupBy { e ->
                val localDate = java.time.Instant.ofEpochMilli(e.startMillis).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
                val j = JalaliDate.fromGregorian(localDate)
                "${j.year}-${j.month}-${j.day}"
            }
            val views = RemoteViews(context.packageName, R.layout.widget_monthly)
            views.setTextViewText(R.id.widget_month_title, "${JalaliDate.MONTHS[m-1]} ${digits(y)}")
            views.setOnClickPendingIntent(R.id.widget_prev, broadcastPending(context, ACTION_PREV, 11))
            views.setOnClickPendingIntent(R.id.widget_next, broadcastPending(context, ACTION_NEXT, 12))
            views.setOnClickPendingIntent(R.id.widget_today, broadcastPending(context, ACTION_TODAY, 13))

            for (i in 0 until 42) {
                val dayView = context.resources.getIdentifier("widget_day_$i", "id", context.packageName)
                val dotViews = (0..2).map { n -> context.resources.getIdentifier("widget_dot_${i}_$n", "id", context.packageName) }
                val noteView = context.resources.getIdentifier("widget_note_$i", "id", context.packageName)
                val day = i - offset + 1
                if (day in 1..count) {
                    views.setViewVisibility(dayView, View.VISIBLE)
                    views.setTextViewText(dayView, digits(day))
                    val isToday = y == today.year && m == today.month && day == today.day
                    val isSelected = day == selected
                    val key = "$y-$m-$day"
                    val allDayEvents = eventsByDay[key].orEmpty()
                    val dayEvents = allDayEvents.filter { it.isOfficial }
                    val personalEvents = allDayEvents.filter { !it.isOfficial && !CalendarData.isOwnSyncedEvent(context, y, m, day, it.id) }
                    val note = CalendarData.getNote(context, y, m, day)
                    val personalLabel = note?.takeIf { it.isNotBlank() } ?: personalEvents.firstOrNull()?.title.orEmpty()
                    views.setInt(dayView, "setBackgroundResource", when { isSelected -> R.drawable.widget_day_selected; isToday -> R.drawable.widget_day_today; else -> R.drawable.widget_day_normal })
                    views.setTextColor(dayView, when { isSelected -> Color.WHITE; else -> Color.rgb(35, 35, 40) })
                    views.setTextViewText(noteView, personalLabel.replace("\n", " "))
                    views.setViewVisibility(noteView, if (personalLabel.isNotBlank()) View.VISIBLE else View.INVISIBLE)
                    dotViews.forEachIndexed { dotIndex, dotId ->
                        if (dotIndex < dayEvents.size.coerceAtMost(3)) {
                            views.setViewVisibility(dotId, View.VISIBLE)
                            views.setInt(dotId, "setBackgroundColor", dayEvents[dotIndex].color)
                        } else views.setViewVisibility(dotId, View.INVISIBLE)
                    }
                    val click = Intent(context, ShamsiWidgetProvider::class.java).setAction(ACTION_SELECT_DAY)
                        .putExtra(CalendarData.EXTRA_YEAR,y).putExtra(CalendarData.EXTRA_MONTH,m).putExtra(CalendarData.EXTRA_DAY,day)
                    views.setOnClickPendingIntent(dayView, PendingIntent.getBroadcast(context, 1000 + widgetId*100 + day, click, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
                } else {
                    views.setViewVisibility(dayView, View.INVISIBLE)
                    views.setViewVisibility(noteView, View.INVISIBLE)
                    dotViews.forEach { views.setViewVisibility(it, View.INVISIBLE) }
                }
            }
            val key = "$y-$m-$selected"
            val chosenEvents = eventsByDay[key].orEmpty().filterNot { CalendarData.isOwnSyncedEvent(context, y, m, selected, it.id) }
            val note = CalendarData.getNote(context,y,m,selected)
            views.setTextViewText(R.id.widget_selected_title, "${digits(selected)} ${JalaliDate.MONTHS[m-1]}")
            val lines = mutableListOf<String>()
            if (!note.isNullOrBlank()) lines += "یادداشت من: $note"
            chosenEvents.take(2).forEach { e -> lines += "• ${e.title}" }
            val missingPermission = !CalendarData.hasCalendarPermission(context)
            views.setTextViewText(R.id.widget_events, when {
                missingPermission -> "برای نمایش رویدادهای تقویم، برنامه را باز و دسترسی تقویم را فعال کن."
                lines.isEmpty() -> "رویدادی برای این روز ثبت نشده است."
                else -> lines.joinToString("\n")
            })
            val open = Intent(context, MainActivity::class.java)
                .putExtra(CalendarData.EXTRA_YEAR,y).putExtra(CalendarData.EXTRA_MONTH,m).putExtra(CalendarData.EXTRA_DAY,selected)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            views.setOnClickPendingIntent(R.id.widget_selected_title, PendingIntent.getActivity(context, 400 + widgetId, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            views.setOnClickPendingIntent(R.id.widget_events, PendingIntent.getActivity(context, 500 + widgetId, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            manager.updateAppWidget(widgetId, views)
        }
    }
}
