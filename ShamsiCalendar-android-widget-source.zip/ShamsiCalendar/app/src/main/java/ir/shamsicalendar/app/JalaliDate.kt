package ir.shamsicalendar.app

import java.time.LocalDate

data class JalaliDate(val year: Int, val month: Int, val day: Int) {
    fun monthName(): String = MONTHS[month - 1]
    companion object {
        val MONTHS = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
        val WEEKDAYS = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")

        fun fromGregorian(date: LocalDate): JalaliDate {
            val gy = date.year
            val gm = date.monthValue
            val gd = date.dayOfMonth
            val gdm = intArrayOf(0,31, if (isLeapGregorian(gy)) 29 else 28,31,30,31,30,31,31,30,31,30,31)
            var gy2 = gy + if (gm > 2) 1 else 0
            var days = 355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd
            for (i in 1 until gm) days += gdm[i]
            var jy = -1595 + 33 * (days / 12053)
            days %= 12053
            jy += 4 * (days / 1461)
            days %= 1461
            if (days > 365) {
                jy += (days - 1) / 365
                days = (days - 1) % 365
            }
            val jm: Int
            val jd: Int
            if (days < 186) {
                jm = 1 + (days / 31)
                jd = 1 + (days % 31)
            } else {
                jm = 7 + ((days - 186) / 30)
                jd = 1 + ((days - 186) % 30)
            }
            return JalaliDate(jy, jm, jd)
        }

        fun toGregorian(jy: Int, jm: Int, jd: Int): LocalDate {
            var days = 355666 + 365 * jy + ((jy / 33) * 8) + (((jy % 33) + 3) / 4)
            days += if (jm <= 6) (jm - 1) * 31 else 186 + (jm - 7) * 30
            days += jd - 1
            var gy = 400 * (days / 146097)
            days %= 146097
            if (days > 36524) {
                gy += 100 * ((days - 1) / 36524)
                days = (days - 1) % 36524
                if (days >= 365) days++
            }
            gy += 4 * (days / 1461)
            days %= 1461
            if (days > 365) {
                gy += (days - 1) / 365
                days = (days - 1) % 365
            }
            var gd = days + 1
            val leap = isLeapGregorian(gy.toInt())
            val monthLengths = intArrayOf(0,31, if (leap) 29 else 28,31,30,31,30,31,31,30,31,30,31)
            var gm = 1
            while (gm <= 12 && gd > monthLengths[gm]) {
                gd -= monthLengths[gm]
                gm++
            }
            return LocalDate.of(gy.toInt(), gm, gd.toInt())
        }

        fun daysInMonth(year: Int, month: Int): Int = when (month) {
            in 1..6 -> 31
            in 7..11 -> 30
            12 -> if (isLeapJalali(year)) 30 else 29
            else -> 30
        }

        // Break-year algorithm for Persian calendar leap years.
        private fun isLeapJalali(year: Int): Boolean {
            val breaks = intArrayOf(-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178)
            if (year < breaks.first() || year >= breaks.last()) return false
            var jp = breaks[0]
            var jump = 0
            for (i in 1 until breaks.size) {
                val jm = breaks[i]
                jump = jm - jp
                if (year < jm) break
                jp = jm
            }
            var n = year - jp
            if (jump - n < 6) n = n - jump + ((jump + 4) / 33) * 33
            var leap = (((n + 1) % 33) - 1) % 4
            if (leap == -1) leap = 4
            return leap == 0
        }
        private fun isLeapGregorian(y: Int) = y % 4 == 0 && (y % 100 != 0 || y % 400 == 0)
    }
}
