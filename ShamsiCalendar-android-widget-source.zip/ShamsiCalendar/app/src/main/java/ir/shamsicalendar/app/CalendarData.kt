package ir.shamsicalendar.app

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset

/** Shared local notes and Android Calendar Provider access for the app and widget. */
object CalendarData {
    const val PREFS = "shamsi_calendar_data"
    const val EXTRA_YEAR = "jalali_year"
    const val EXTRA_MONTH = "jalali_month"
    const val EXTRA_DAY = "jalali_day"

    fun noteKey(year: Int, month: Int, day: Int) = "note:$year-$month-$day"
    private fun syncedEventKey(year: Int, month: Int, day: Int) = "synced_event:$year-$month-$day"

    fun getNote(context: Context, year: Int, month: Int, day: Int): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(noteKey(year, month, day), null)

    enum class SaveResult { SYNCED, LOCAL_ONLY_NO_PERMISSION, LOCAL_ONLY_NO_GOOGLE_CALENDAR }

    /** Saves the personal label locally, then mirrors it to an all-day event in a Google calendar. */
    fun saveNote(context: Context, year: Int, month: Int, day: Int, note: String): SaveResult {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val clean = note.trim()
        prefs.edit().apply {
            if (clean.isBlank()) remove(noteKey(year, month, day)) else putString(noteKey(year, month, day), clean)
        }.apply()
        return syncNoteToGoogleCalendar(context, year, month, day, clean)
    }

    fun hasCalendarPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    fun hasWriteCalendarPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED

    data class CalendarEvent(
        val id: Long,
        val title: String,
        val startMillis: Long,
        val endMillis: Long,
        val calendarId: Long,
        val color: Int,
        val isOfficial: Boolean
    )

    fun eventsForGregorianRange(context: Context, start: LocalDate, endExclusive: LocalDate): List<CalendarEvent> {
        if (!hasCalendarPermission(context)) return emptyList()
        val zone = ZoneId.systemDefault()
        val begin = start.atStartOfDay(zone).toInstant().toEpochMilli()
        val finish = endExclusive.atStartOfDay(zone).toInstant().toEpochMilli()
        val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        android.content.ContentUris.appendId(builder, begin)
        android.content.ContentUris.appendId(builder, finish)
        val calendarInfo = calendarInfo(context)
        val result = mutableListOf<CalendarEvent>()
        val projection = arrayOf(
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.CALENDAR_ID
        )
        try {
            context.contentResolver.query(builder.build(), projection, null, null, CalendarContract.Instances.BEGIN + " ASC")?.use { c ->
                val idCol = c.getColumnIndexOrThrow(CalendarContract.Instances.EVENT_ID)
                val titleCol = c.getColumnIndexOrThrow(CalendarContract.Instances.TITLE)
                val beginCol = c.getColumnIndexOrThrow(CalendarContract.Instances.BEGIN)
                val endCol = c.getColumnIndexOrThrow(CalendarContract.Instances.END)
                val calCol = c.getColumnIndexOrThrow(CalendarContract.Instances.CALENDAR_ID)
                while (c.moveToNext()) {
                    val calendarId = c.getLong(calCol)
                    val info = calendarInfo[calendarId]
                    result += CalendarEvent(c.getLong(idCol), c.getString(titleCol) ?: "بدون عنوان", c.getLong(beginCol), c.getLong(endCol), calendarId, info?.first ?: 0xFF6750A4.toInt(), info?.second ?: false)
                }
            }
        } catch (_: SecurityException) { }
        return result
    }

    private fun calendarInfo(context: Context): Map<Long, Pair<Int, Boolean>> {
        if (!hasCalendarPermission(context)) return emptyMap()
        val result = mutableMapOf<Long, Pair<Int, Boolean>>()
        val projection = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.CALENDAR_COLOR, CalendarContract.Calendars.CALENDAR_DISPLAY_NAME, CalendarContract.Calendars.NAME)
        try {
            context.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, projection, null, null, null)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(CalendarContract.Calendars._ID)
                val colorCol = c.getColumnIndexOrThrow(CalendarContract.Calendars.CALENDAR_COLOR)
                val displayCol = c.getColumnIndexOrThrow(CalendarContract.Calendars.CALENDAR_DISPLAY_NAME)
                val nameCol = c.getColumnIndexOrThrow(CalendarContract.Calendars.NAME)
                while (c.moveToNext()) {
                    val label = (c.getString(displayCol).orEmpty() + " " + c.getString(nameCol).orEmpty()).lowercase()
                    val official = listOf("holiday", "holidays", "تعطیلات", "مناسبت", "تقویم رسمی", "official calendar").any { label.contains(it) }
                    result[c.getLong(idCol)] = c.getInt(colorCol) to official
                }
            }
        } catch (_: SecurityException) { }
        return result
    }

    fun eventsForJalaliDay(context: Context, year: Int, month: Int, day: Int): List<CalendarEvent> {
        val start = JalaliDate.toGregorian(year, month, day)
        return eventsForGregorianRange(context, start, start.plusDays(1))
    }

    /** Event IDs owned by the app are kept separate from the colored calendar dots. */
    fun isOwnSyncedEvent(context: Context, year: Int, month: Int, day: Int, eventId: Long): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(syncedEventKey(year, month, day), -1L) == eventId

    fun syncAllLocalNotes(context: Context): Boolean {
        if (!hasCalendarPermission(context) || !hasWriteCalendarPermission(context)) return false
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        var allSynced = true
        prefs.all.keys.filter { it.startsWith("note:") }.forEach { key ->
            val parts = key.removePrefix("note:").split("-")
            if (parts.size == 3) {
                val y = parts[0].toIntOrNull(); val m = parts[1].toIntOrNull(); val d = parts[2].toIntOrNull()
                if (y != null && m != null && d != null) {
                    val note = prefs.getString(key, "").orEmpty()
                    if (syncNoteToGoogleCalendar(context, y, m, d, note) != SaveResult.SYNCED) allSynced = false
                }
            }
        }
        return allSynced
    }

    private fun syncNoteToGoogleCalendar(context: Context, year: Int, month: Int, day: Int, note: String): SaveResult {
        if (!hasCalendarPermission(context) || !hasWriteCalendarPermission(context)) return SaveResult.LOCAL_ONLY_NO_PERMISSION
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val idKey = syncedEventKey(year, month, day)
        val existingId = prefs.getLong(idKey, -1L)
        try {
            if (note.isBlank()) {
                if (existingId >= 0) context.contentResolver.delete(
                    android.content.ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, existingId), null, null
                )
                prefs.edit().remove(idKey).apply()
                return SaveResult.SYNCED
            }
            val calendarId = findGoogleWritableCalendar(context) ?: return SaveResult.LOCAL_ONLY_NO_GOOGLE_CALENDAR
            val start = JalaliDate.toGregorian(year, month, day)
            val values = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, calendarId)
                put(CalendarContract.Events.TITLE, note)
                put(CalendarContract.Events.DESCRIPTION, "یادداشت ایجادشده در تقویم شمسی")
                put(CalendarContract.Events.DTSTART, start.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
                put(CalendarContract.Events.DTEND, start.plusDays(1).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
                put(CalendarContract.Events.EVENT_TIMEZONE, "UTC")
                put(CalendarContract.Events.ALL_DAY, 1)
            }
            val eventUri = if (existingId >= 0) {
                val uri = android.content.ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, existingId)
                val updated = context.contentResolver.update(uri, values, null, null)
                if (updated > 0) uri else context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
            } else context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
            val newId = eventUri?.lastPathSegment?.toLongOrNull() ?: return SaveResult.LOCAL_ONLY_NO_GOOGLE_CALENDAR
            prefs.edit().putLong(idKey, newId).apply()
            return SaveResult.SYNCED
        } catch (_: SecurityException) {
            return SaveResult.LOCAL_ONLY_NO_PERMISSION
        } catch (_: Exception) {
            return SaveResult.LOCAL_ONLY_NO_GOOGLE_CALENDAR
        }
    }

    private fun findGoogleWritableCalendar(context: Context): Long? {
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.ACCOUNT_TYPE,
            CalendarContract.Calendars.ACCOUNT_NAME,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,
            CalendarContract.Calendars.SYNC_EVENTS,
            CalendarContract.Calendars.VISIBLE
        )
        val candidates = mutableListOf<Triple<Long, Int, String>>()
        try {
            context.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, projection, null, null, null)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(CalendarContract.Calendars._ID)
                val typeCol = c.getColumnIndexOrThrow(CalendarContract.Calendars.ACCOUNT_TYPE)
                val nameCol = c.getColumnIndexOrThrow(CalendarContract.Calendars.ACCOUNT_NAME)
                val accessCol = c.getColumnIndexOrThrow(CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL)
                val syncCol = c.getColumnIndexOrThrow(CalendarContract.Calendars.SYNC_EVENTS)
                val visibleCol = c.getColumnIndexOrThrow(CalendarContract.Calendars.VISIBLE)
                while (c.moveToNext()) {
                    val type = c.getString(typeCol).orEmpty()
                    val name = c.getString(nameCol).orEmpty()
                    val access = c.getInt(accessCol)
                    val sync = c.getInt(syncCol) == 1
                    val visible = c.getInt(visibleCol) == 1
                    if (type == "com.google" && name.contains("@") && access >= CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR && sync && visible) {
                        candidates += Triple(c.getLong(idCol), access, name)
                    }
                }
            }
        } catch (_: SecurityException) { }
        return candidates.sortedByDescending { it.second }.firstOrNull()?.first
    }
}
