package ir.shamsicalendar.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.CalendarContract
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.READ_CALENDAR] == true && result[Manifest.permission.WRITE_CALENDAR] == true) {
            CalendarData.syncAllLocalNotes(this)
            Toast.makeText(this, "تقویم برای همگام‌سازی آماده شد.", Toast.LENGTH_SHORT).show()
        }
        ShamsiWidgetProvider.refresh(this)
        setContent { MaterialTheme { CalendarScreen(this, intent) } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { CalendarScreen(this, intent) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        setContent { MaterialTheme { CalendarScreen(this, intent) } }
    }

    fun requestCalendarPermission() { permissionLauncher.launch(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CalendarScreen(activity: MainActivity, launchIntent: Intent?) {
    val context = activity
    val today = remember { LocalDate.now() }
    val todayJalali = remember { JalaliDate.fromGregorian(today) }
    var shownYear by remember { mutableIntStateOf(launchIntent?.getIntExtra(CalendarData.EXTRA_YEAR, todayJalali.year) ?: todayJalali.year) }
    var shownMonth by remember { mutableIntStateOf(launchIntent?.getIntExtra(CalendarData.EXTRA_MONTH, todayJalali.month) ?: todayJalali.month) }
    var selectedDay by remember { mutableIntStateOf(launchIntent?.getIntExtra(CalendarData.EXTRA_DAY, todayJalali.day) ?: todayJalali.day) }
    var showAddDialog by remember { mutableStateOf(false) }
    var eventTitle by remember { mutableStateOf("") }
    var noteText by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    val selectedKey = "$shownYear-$shownMonth-$selectedDay"
    val hasPermission = CalendarData.hasCalendarPermission(context)

    LaunchedEffect(selectedKey, refresh) {
        noteText = CalendarData.getNote(context, shownYear, shownMonth, selectedDay).orEmpty()
    }
    val firstGregorian = remember(shownYear, shownMonth) { JalaliDate.toGregorian(shownYear, shownMonth, 1) }
    val offset = (firstGregorian.dayOfWeek.value + 1) % 7
    val count = JalaliDate.daysInMonth(shownYear, shownMonth)
    val cells = remember(shownYear, shownMonth) { List(offset) { 0 } + (1..count).toList() + List((7 - (offset + count) % 7) % 7) { 0 } }
    val monthLabel = "${JalaliDate.MONTHS[shownMonth - 1]} ${shownYear.toPersianDigits()}"
    val selectedGregorian = remember(shownYear, shownMonth, selectedDay) { JalaliDate.toGregorian(shownYear, shownMonth, selectedDay) }
    val events = remember(shownYear, shownMonth, hasPermission, refresh) {
        if (hasPermission) CalendarData.eventsForGregorianRange(context,
            JalaliDate.toGregorian(shownYear, shownMonth, 1),
            if (shownMonth == 12) JalaliDate.toGregorian(shownYear + 1, 1, 1) else JalaliDate.toGregorian(shownYear, shownMonth + 1, 1)
        ) else emptyList()
    }
    val eventsByDay = events.groupBy { event ->
        val date = Instant.ofEpochMilli(event.startMillis).atZone(ZoneId.systemDefault()).toLocalDate()
        val j = JalaliDate.fromGregorian(date)
        "${j.year}-${j.month}-${j.day}"
    }
    val dayEvents = eventsByDay[selectedKey].orEmpty()

    Scaffold(
        topBar = { TopAppBar(title = { Text("تقویم شمسی", fontWeight = FontWeight.Bold) }, actions = {
            IconButton(onClick = { shownYear = todayJalali.year; shownMonth = todayJalali.month; selectedDay = todayJalali.day; refresh++ }) { Icon(Icons.Default.Today, contentDescription = "امروز") }
        }) },
        floatingActionButton = { FloatingActionButton(onClick = { eventTitle = noteText; showAddDialog = true }) { Icon(Icons.Default.Add, contentDescription = "یادداشت روز") } }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp).background(MaterialTheme.colorScheme.background), horizontalAlignment = Alignment.CenterHorizontally) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("امروز", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("${todayJalali.day.toPersianDigits()} ${todayJalali.monthName()} ${todayJalali.year.toPersianDigits()}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text(today.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale("fa")), color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                IconButton(onClick = { if (shownMonth == 1) { shownMonth = 12; shownYear-- } else shownMonth--; selectedDay = 1 }) { Icon(Icons.Default.ChevronRight, contentDescription = "ماه قبل") }
                Text(monthLabel, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                IconButton(onClick = { if (shownMonth == 12) { shownMonth = 1; shownYear++ } else shownMonth++; selectedDay = 1 }) { Icon(Icons.Default.ChevronLeft, contentDescription = "ماه بعد") }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) { JalaliDate.WEEKDAYS.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.secondary) } }
            LazyVerticalGrid(columns = GridCells.Fixed(7), modifier = Modifier.fillMaxWidth().heightIn(max = 340.dp)) {
                items(cells) { day ->
                    Box(Modifier.aspectRatio(1f).padding(3.dp), contentAlignment = Alignment.Center) {
                        if (day != 0) {
                            val isToday = shownYear == todayJalali.year && shownMonth == todayJalali.month && day == todayJalali.day
                            val isSelected = day == selectedDay
                            val key = "$shownYear-$shownMonth-$day"
                            val hasItems = eventsByDay[key].orEmpty().isNotEmpty() || !CalendarData.getNote(context, shownYear, shownMonth, day).isNullOrBlank()
                            Box(Modifier.fillMaxSize().clip(CircleShape).background(when { isSelected -> MaterialTheme.colorScheme.primary; isToday -> MaterialTheme.colorScheme.tertiaryContainer; else -> MaterialTheme.colorScheme.surface }).clickable { selectedDay = day }, contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                    Text(day.toPersianDigits(), color = when { isSelected -> MaterialTheme.colorScheme.onPrimary; isToday -> MaterialTheme.colorScheme.onTertiaryContainer; else -> MaterialTheme.colorScheme.onSurface }, fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal)
                                    if (hasItems) Box(Modifier.padding(top = 2.dp).size(4.dp).clip(CircleShape).background(if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary))
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("رویدادهای ${selectedDay.toPersianDigits()} ${JalaliDate.MONTHS[shownMonth - 1]}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(6.dp))
            if (!hasPermission) {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("برای نمایش رویدادهای Google Calendar، دسترسی تقویم لازم است.")
                        TextButton(onClick = { activity.requestCalendarPermission() }) { Text("فعال‌کردن دسترسی") }
                    }
                }
            }
            val note = CalendarData.getNote(context, shownYear, shownMonth, selectedDay)
            if (!note.isNullOrBlank()) EventCard("یادداشت من", note, null) {}
            if (dayEvents.isEmpty() && note.isNullOrBlank()) {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
                    Text(if (hasPermission) "برای این روز رویدادی ثبت نشده است." else "یادداشت روز را با دکمهٔ + اضافه کن.", Modifier.fillMaxWidth().padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            dayEvents.take(5).forEach { e ->
                val time = Instant.ofEpochMilli(e.startMillis).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))
                EventCard(time, e.title, e.id) {
                    val viewIntent = Intent(Intent.ACTION_VIEW).setData(CalendarContract.Events.CONTENT_URI.buildUpon().appendPath(e.id.toString()).build())
                    try { context.startActivity(viewIntent) } catch (_: Exception) { }
                }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(onDismissRequest = { showAddDialog = false }, title = { Text("یادداشت روز") },
            text = { OutlinedTextField(value = eventTitle, onValueChange = { eventTitle = it }, label = { Text("یادداشت یا عنوان") }, minLines = 2) },
            confirmButton = { TextButton(onClick = {
                val result = CalendarData.saveNote(context, shownYear, shownMonth, selectedDay, eventTitle)
                showAddDialog = false; refresh++; ShamsiWidgetProvider.refresh(context)
                when (result) {
                    CalendarData.SaveResult.SYNCED -> Toast.makeText(context, "یادداشت ذخیره و با Google Calendar همگام شد.", Toast.LENGTH_LONG).show()
                    CalendarData.SaveResult.LOCAL_ONLY_NO_PERMISSION -> { Toast.makeText(context, "یادداشت محلی ذخیره شد؛ برای همگام‌سازی، دسترسی تقویم را فعال کن.", Toast.LENGTH_LONG).show(); activity.requestCalendarPermission() }
                    CalendarData.SaveResult.LOCAL_ONLY_NO_GOOGLE_CALENDAR -> Toast.makeText(context, "یادداشت محلی ذخیره شد؛ تقویم Google قابل‌نوشتن پیدا نشد. همگام‌سازی حساب را بررسی کن.", Toast.LENGTH_LONG).show()
                }
            }) { Text("ذخیره") } },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("انصراف") } })
    }
}

@Composable
private fun EventCard(label: String, title: String, eventId: Long?, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable(enabled = eventId != null, onClick = onClick), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            Text(title, color = MaterialTheme.colorScheme.onSecondaryContainer)
        }
    }
}

private fun Int.toPersianDigits(): String = toString().map { c -> if (c in '0'..'9') ('۰'.code + (c.code - '0'.code)).toChar() else c }.joinToString("")
